const int TRIG_PIN = 11;
const int ECHO_PIN = 10;
const int BUZZER_PIN = 7;
const int LED_PIN = 12;

void setup() {
  Serial.begin(9600);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);
  Serial.println("SIMULATION STARTED - CLICK SENSOR TO ADJUST DISTANCE");
}

void loop() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);
  
  long duration = pulseIn(ECHO_PIN, HIGH);
  int distance = duration * 0.034 / 2;

  Serial.print("Distance: ");
  Serial.println(distance);

  if (distance < 100) { // WARNING: Very Close
    tone(BUZZER_PIN, 2000); 
    digitalWrite(LED_PIN, HIGH);
    delay(100); 
    digitalWrite(LED_PIN, LOW);
    delay(100);
  } 
  else if (distance >= 100 && distance < 200) { // ALERT: Moving closer
    tone(BUZZER_PIN, 500); 
    digitalWrite(LED_PIN, HIGH); 
  } 
  else { // SAFE
    noTone(BUZZER_PIN);
    digitalWrite(LED_PIN, LOW);
  }

  delay(50); // Fast refresh rate
}